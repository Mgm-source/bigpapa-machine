<?php
$this ->load->view('partials/header');
$this ->load->view($body);
$this ->load->view('partials/footer');