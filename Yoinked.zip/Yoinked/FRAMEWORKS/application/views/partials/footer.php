  <div id="chatspace">
    
  </div>
  <footer class="footer page-footer font-small grey">
    <div class="footer-copyright text-center py-3">
      <img src="https://upload.wikimedia.org/wikipedia/en/thumb/9/94/Manchester_Metropolitan_University_logo.svg/220px-Manchester_Metropolitan_University_logo.svg.png">
    </div>
    <button id="chatButton" class="open-button btn btn-success">Chat</button>
    <div class="chat-popup pull-right" id="myForm">
      <form id="chatform" class="form-container">
        <input type="text" placeholder="Type your message" id="message">
        <button type="submit" id="submit">Send</button> 
      </form>
    </div>
  </footer>

</body>
</html>