var app = new Vue({
    // Add the id here.
    el: 'app',
    data: {
        // Create your data here.
    },
    methods: {
        //    Add your methods here.       
    }
});